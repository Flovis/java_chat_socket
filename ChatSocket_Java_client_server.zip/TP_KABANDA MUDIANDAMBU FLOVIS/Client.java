import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    public static void main( String[] args ) {
        Socket s;
        BufferedReader bufferedReader;
        PrintWriter printWriter;
        Scanner sc = new Scanner(System.in);

        try {
            s = new Socket("localhost",8000);
            printWriter =  new PrintWriter(s.getOutputStream());
            bufferedReader = new BufferedReader(new InputStreamReader(s.getInputStream()));

            Thread send = new Thread(new Runnable() {
                String message;
                @Override
                public void run() {
                    while (true){
                        message = sc.nextLine();
                        printWriter.println(message);
                        printWriter.flush();
                    }
                }
            });
            send.start();

            Thread receve = new Thread(new Runnable() {
                String message;
                @Override
                public void run() {
                    try {
                        message = bufferedReader.readLine();
                        while (message != null){
                            System.out.println("Server: "+message);
                            message = bufferedReader.readLine();
                        }
                        //sotir de la boucle client deconnecté
                        System.out.println("client deconnecté");
                        printWriter.close();
                        s.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });


        } catch (Exception e) {
            e.printStackTrace();
        }
    }




}
