import sun.java2d.loops.GraphicsPrimitive;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
    public static void main( String[] args ) {
        ServerSocket ss;
        Socket s;
        BufferedReader bufferedReader;
        PrintWriter printWriter;
        Scanner sc = new Scanner(System.in);

        try {
            ss = new ServerSocket(8000);
            s = ss.accept();
            printWriter = new PrintWriter(s.getOutputStream());
            bufferedReader = new BufferedReader(new InputStreamReader(s.getInputStream()));

            Thread send = new Thread(new Runnable() {
                String message;
                @Override
                public void run() {
                    while (true){
                        message = sc.nextLine();
                        printWriter.println(message);
                        printWriter.flush();
                    }
                }
            });
            send.start();

            Thread receve = new Thread(new Runnable() {
                String message;
                @Override
                public void run() {
                    try {
                        message = bufferedReader.readLine();
                        while (message != null){
                            System.out.println("Client: "+message);
                            message = bufferedReader.readLine();
                        }
                        //sotir de la boucle client deconnecté
                        System.out.println("client deconnecté");
                        printWriter.close();
                        ss.close();
                        s.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            receve.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
